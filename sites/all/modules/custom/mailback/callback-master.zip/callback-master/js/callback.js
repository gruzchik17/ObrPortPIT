(function ($) {
    $(function () {
        jQuery(document).ready(function () {
            
            $("#edit-phone").mask("+9 (999) 999-99-99");
            
         });
    });
})(jQuery);
